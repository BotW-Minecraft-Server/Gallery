package link.botwmcs.gallery.registration;

import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.player.Player;

public interface GalleryPayload extends CustomPacketPayload {
    void handle(Player var1, Runner var2);

    public interface Runner {
        void run(Runnable var1);
    }
}