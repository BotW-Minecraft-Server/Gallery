package link.botwmcs.gallery.registration;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;


public class Network {
    public static void register(Registrar c) {
        // todo: registrar

    }

    public interface Registrar {
        <T extends GalleryPayload> void register(CustomPacketPayload.Type<T> var1, StreamCodec<FriendlyByteBuf, T> var2, boolean var3);
    }

}
