package link.botwmcs.gallery.registration;

import net.minecraft.resources.ResourceLocation;

public interface GalleryRegisterHelper<T> {
    void register(ResourceLocation var1, T var2);
}